The instances are structured as follows:
	1- T = 4.
	2- The first point is the stating and ending node of the route.
	3- The file with extension .csv contains:
		- name: name of the POI.
		- amenity: POI types.
		- osmid: POI ID.
		- lng: longitude
		- latitude: latitude.
		- visit_time: v_i.
		- interest: S_i.
		- recommendation_factor_[t]: recommendation factor in period t.
	4- The file with extension .txt is the square distance matrix.