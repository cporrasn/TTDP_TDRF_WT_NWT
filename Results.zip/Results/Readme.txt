1- In the NWT folder you will find the results for the model without waiting times (NWT), and in the WT folder you will find the results of the model with waiting time (WT).
2- The files are use .json extension and have the following structure:
	- "NumPOIs": size of permutation
    - "Time": execution time
    - "TotalVisitTime": total visit time
    - "TotaltravelTime": total travel time
    - "arrival": a_i
    - "arrivalH": a_i of this solution without waiting time
    - "objH": total interest of this solution without waiting time
    - "objective": total interest
    - "permutation": permutation without the initial node.
    - "status": ignore